// pages/index.js

export default function Home() {
  return (
    <div style={{ padding: 20, fontFamily: "Arial" }}>
      <h1>Bienvenue sur LocTave !</h1>
      <p>La plateforme simple et transparente de location de chambres au Bénin.</p>
      <p>Projet en cours de développement.</p>
    </div>
  );
}
