# LocTave
Plateforme simple et sécurisée de location de chambres au Bénin.